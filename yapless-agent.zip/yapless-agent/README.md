# Yapless Agent (APK)

Application agent Yapless : interface mobile-money repensée façon app native
(grille d'opérateurs + flux de transaction), **distincte du site web**.
WebView embarquant une UI 100 % autonome (`app/src/main/assets/index.html`).

## Construire l'APK (via GitHub Actions)

1. Poussez ce dossier dans un dépôt GitHub (ex. `pacomeyapi-spec/yapless-agent`).
2. Créez les secrets du dépôt (*Settings → Secrets and variables → Actions*) :
   - `KEYSTORE_BASE64` — `base64 -w0 yapson.keystore`
   - `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`
   > Sans ces secrets, la CI build quand même l'APK signé en debug.
3. À chaque push sur `main`, l'APK est publié en **Release au tag `latest`**
   (`yapless-agent.apk`, téléchargeable sans login), comme vos autres projets.

Build manuel : onglet **Actions → Build Yapless Agent APK → Run workflow**.

## Brancher le vrai backend

Toute l'UI marche en **mode démo** (USSD simulé). Pour la connecter au moteur
`yapless-ussd` réel, éditez `index.html` :

- `const API_BASE = "https://yapless-ussd-production.up.railway.app";`
- Complétez `YaplessAPI.submit()` / `pollStatus()` avec vos routes agent.
- Logique de solde déjà respectée : **RETRAIT réussi → +montant, DÉPÔT réussi → −montant**.

Pour pointer la WebView vers le site distant plutôt que l'UI embarquée,
changez `startUrl` dans `MainActivity.kt`.

## Personnaliser

- Opérateurs, codes USSD, montants rapides : tableau `OPERATORS` / `QUICK_AMOUNTS` (`index.html`).
- Nom de l'agent / site / TX affichés en haut : bloc `.topbar` (`index.html`).
- Couleurs de marque : `:root` (`index.html`) et `res/values/colors.xml`.
