package net.yapson.agent

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView

    /**
     * Interface de démarrage.
     *  - Par défaut : UI embarquée (app 100% autonome, hors-ligne, distincte du site).
     *  - Pour pointer vers le backend distant, remplacez par :
     *      "https://yapless-ussd-production.up.railway.app/agent"
     */
    private val startUrl = "file:///android_asset/index.html"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Barres système : haut = ink (top bar de l'app), bas = clair
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = Color.parseColor("#0F1518")
        window.navigationBarColor = Color.parseColor("#F3F4F6")
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false        // icônes claires sur ink
            isAppearanceLightNavigationBars = true      // icônes sombres sur fond clair
        }

        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#F3F4F6"))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
                loadWithOverviewMode = true
                useWideViewPort = true
                builtInZoomControls = false
                displayZoomControls = false
                textZoom = 100
                mediaPlaybackRequiresUserGesture = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    safeBrowsingEnabled = false
                }
            }
            overScrollMode = View.OVER_SCROLL_NEVER
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                    // On garde tout dans la WebView (asset local ou même origine)
                    return false
                }
            }
        }
        setContentView(web)
        web.loadUrl(startUrl)

        // Bouton retour : on délègue d'abord au JS (fermer sheet/modal), sinon on quitte
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.handleBack && window.handleBack()") { result ->
                    if (result != "true") {
                        if (web.canGoBack()) web.goBack() else finish()
                    }
                }
            }
        })
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
